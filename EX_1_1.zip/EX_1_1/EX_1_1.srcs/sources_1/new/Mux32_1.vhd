----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 02.02.2026 17:04:46
-- Design Name: 
-- Module Name: Mux32_1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Mux32_1 is
    port( a : in std_logic_vector(0 to 31);
          s : in std_logic_vector(4 to 0);
          y0: out std_logic
    );
end Mux32_1;

architecture Structural of Mux32_1 is
    
    component mux_2_1
       port( 	a0 	: in STD_LOGIC;
			a1 	: in STD_LOGIC;
			s 	: in STD_LOGIC;
			y 	: out STD_LOGIC
	);
	end component;

	component mux8_1 
	Port (
    a : in  STD_LOGIC_VECTOR(0 to 7);
    s : in  STD_LOGIC_VECTOR(0 to 2);
    y : out STD_LOGIC
  );
     end component;
   
   signal s1 : std_logic_vector(2 downto 0);
   signal s2 : std_logic;
   signal s3 : std_logic;
    
   signal y1 : std_logic_vector(0 to 3);
   signal y2 : std_logic_vector(0 to 1);
   signal y : std_logic;
    
begin
    --1. suddivisione del selettore
    s1 <= s(2 downto 0);
    s2 <= s(3);
    s3 <= s(4);
    
    --2 primo livello del 4 mux 8:1
    
    mux_8_0:  mux8_1
        port map (
            a => a(0 to 7),
            s => s1,
            y => y1(0)
            );
            
    mux_8_1: mux8_1
        port map (
            a => a(8 to 15),
            s => s1,
            y => y1(1)
            );
            
    mux_8_2: mux8_1
        port map (
            a => a(16 to 23),
            s => s1,
            y => y1(2)
            );
            
     mux_8_3: mux8_1
        port map (
            a => a(24 to 31),
            s => s1,
            y => y1(3)
            );
        --secondo livello                  
     mux2_0: mux_2_1
        port map (
            a0 => y1(0),
            a1 => y1(1),
            s => s2,
            y => y2(0)
            );
      mux2_1: mux_2_1
        port map (
            a0 => y1(2),
            a1 => y1(3),
            s => s2,
            y => y2(1)
            );
        --terzo livello
       mux2_2: mux_2_1
        port map (
            a0 => y2(0),
            a1 => y2(1),
            s => s3,
            y => y0
            );
end Structural;
